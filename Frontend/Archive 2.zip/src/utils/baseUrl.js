export default {
  baseURL: "https://zjoxobi1x6.execute-api.us-east-1.amazonaws.com/dev/",
};
