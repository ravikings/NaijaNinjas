import React, { useEffect } from "react";
import Header from "../../Layout/Header";
import Footer from "../../Layout/Footer";
import Avatar from "@material-ui/core/Avatar";
import { Divider, Grid, Hidden } from "@material-ui/core";
import { useStyles } from "./MakeOfferStyles";
import Ratings from "./components/Ratings";
import Feedback from "./components/Feedback";
import HourlyRate from "./components/HourlyRate";
import MakeOfferForm from "./components/MakeOfferForm";
import SocialMedia from "./components/SocialMedia";
import Skills from "./components/Skills";
import Attachments from "./components/Attachments";
import TabsGroup from "./components/TabsGroup";
import { useHistory, useLocation, useParams } from "react-router-dom";
import createRequest from "../../../utils/axios";
import ClipLoader from "react-spinners/ClipLoader";
import { toast } from "react-toastify";

var bnr = require("../../../images/banner/bnr5.png");

const blogGrid = [
  {
    image: require("../../../images/blog/grid/pic1.jpg"),
  },
  {
    image: require("../../../images/blog/grid/pic2.jpg"),
  },
  {
    image: require("../../../images/blog/grid/pic3.jpg"),
  },
  {
    image: require("../../../images/blog/grid/pic4.jpg"),
  },
];

function MakeOfferPage() {
  const classes = useStyles();
  const { id } = useParams();
  const history = useHistory();
  const [user, setUser] = React.useState(null);
  const [resume, setResume] = React.useState(null);

  const getResume = async () => {
    try {
      const { data } = await createRequest().get(
        `/api/v1/account/user-resume/${id}/`
      );
      setResume(data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    handleRequest();
    getResume();
  }, [id]);

  const handleRequest = async () => {
    try {
      const res = await createRequest().get(
        `/api/v1/account/user-search-detials/${id}/`
      );
      setUser(res.data);
    } catch (error) {
      toast.error("Something went wrong");

      history.push("/");
    }
  };

  return (
    <>
      <Header />
      {user ? (
        <div className="page-content bg-white">
          <div
            className="dez-bnr-inr d-flex align-items-center"
            style={{ backgroundImage: "url(" + bnr + ")" }}
          >
            <div className="">
              <Grid container spacing={2} className={classes.headerGrid}>
                <Grid item>
                  <Avatar
                    variant={"square"}
                    className={classes.avatar}
                    src={user.photo}
                  >
                    K
                  </Avatar>
                </Grid>
                <Grid item>
                  <Grid
                    container
                    direction="column"
                    justifyContent="space-between"
                    style={{ height: "100%", padding: "5px 0px" }}
                  >
                    <Grid item>
                      <div style={{ marginBottom: 5 }}>
                        {user.first_name} {user.last_name}
                      </div>
                      <div style={{ color: "gray" }}>iOS Expert + Node Dev</div>
                    </Grid>
                    <Hidden xsDown>
                      <Grid item>
                        <Ratings />
                      </Grid>
                    </Hidden>
                  </Grid>
                </Grid>
                <Hidden smUp>
                  <Grid item xs={12}>
                    <Ratings />
                  </Grid>
                </Hidden>
              </Grid>
            </div>
          </div>

          <div className={classes.main}>
            <Grid container spacing={8}>
              <Grid item xs={12} sm={12} md={7} lg={8}>
                <TabsGroup data={user.description} resume={resume} />
                <Feedback />
              </Grid>
              <Grid item xs={12} sm={12} md={5} lg={4}>
                <HourlyRate />
                <Divider style={{ margin: "30px 0px" }} />
                <MakeOfferForm />
                <Divider style={{ margin: "30px 0px" }} />
                <SocialMedia />
                <Divider style={{ margin: "30px 0px" }} />
                <Skills />
                <Divider style={{ margin: "30px 0px" }} />
                <Attachments />
              </Grid>
            </Grid>
          </div>
        </div>
      ) : (
        <div className="loader">
          <ClipLoader color={"#2e55fa"} loading={true} size={150} />
        </div>
      )}
      <Footer />
    </>
  );
}
export default MakeOfferPage;
