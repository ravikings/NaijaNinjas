import React from "react";

function Videos(props) {
  return <div>Videos will be displayed here</div>;
}

export default Videos;
