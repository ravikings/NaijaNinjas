export {default as Gallery} from "./Gallery"
export {default as Services} from "./Services"
export {default as AboutMe} from "./AboutMe"
export {default as Resume} from "./Resume"
