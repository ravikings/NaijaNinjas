import React from "react";

function Photos(props) {
  return <div>Photos will be displayed here</div>;
}

export default Photos;
